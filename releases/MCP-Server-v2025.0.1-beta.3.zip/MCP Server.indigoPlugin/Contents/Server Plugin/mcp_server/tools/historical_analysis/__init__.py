"""
Historical data analysis tool using direct InfluxDB queries.
"""

from .main import HistoricalAnalysisHandler

__all__ = ['HistoricalAnalysisHandler']