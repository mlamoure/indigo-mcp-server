"""
Get devices by type handler.
"""

from .main import GetDevicesByTypeHandler

__all__ = ['GetDevicesByTypeHandler']